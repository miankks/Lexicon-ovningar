﻿namespace Övening3_Arv
{
    internal class Worm : Animal
    {
        private string move = "Crawl";
        private string symmetricalBodyLength; 

        public Worm()
        {

        }

        public string Move { get; set; }
        public string SymmetricalBodyLength { get; set; }
    }
}