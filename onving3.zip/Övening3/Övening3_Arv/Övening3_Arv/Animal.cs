﻿namespace Övening3_Arv
{
    internal class Animal
    {

        private string name;
        private int lifespan;
        private double length;
        private double height;
        private double weight;
        private string speed;

        public Animal()
        {
            
        }

        public int Lifespan { get; set; }
        public double Length { get; set; }
        public double Height { get; set; }
        public double Weight { get; set; }
        public string Name { get; set; }
        public string Speed { get; set; }
    }
}