﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
       public enum FuelType { Gasoline=0, Diesel=1, Hybrid=2, Ethanol=3}
    class Car : Vehicle
    {
        public FuelType Fuel { get; set; }
        public override string Stats()
        {
            return base.Stats() + $"\nFuel Type: {Fuel}";
        }
    }
}
