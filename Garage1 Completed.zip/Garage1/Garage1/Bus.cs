﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class Bus : Vehicle
    {
        public int NumberOfSeats { get; set; }
        public override string Stats()
        {
            return base.Stats()+ $"\nNumberOfSeats: {NumberOfSeats}";
        }
    }
}
