﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Övning_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // int findAge;
            string statement;
            bool quit = true;
            DateTime a = new DateTime();
            a = DateTime.Now;
            while (quit)
            {
                Console.Clear();
                Console.CursorLeft = 50;                                // Move heading to the middle. 

                a = DateTime.Now;
                Console.ForegroundColor = ConsoleColor.White;           // Reset to white again
                Console.WriteLine(a);
                Console.WriteLine("HuvudMeny \n\n-----------------------------------------------------------------\n");
                Console.WriteLine("Ni har kommit till huvudmeny och skriva bara siffror för att testa olika funktioner \n");
                Console.WriteLine("Tryck 0 tangent om ni vill stänga programmet!.");
                Console.WriteLine("Tryck 1 tangent för att visa ungdomar och pensionär.");
                Console.WriteLine("Tryck 2 tangent och anger en godtycklig text.");
                Console.WriteLine("Tryck 3 tangent för förklaring i texten.");

                //int number = Convert.ToInt32(Console.ReadLine());
                int number = AskForInt("");

                switch (number)
                {
                    case 0:
                        quit = false;
                        break;

                    case 1:
                        Console.WriteLine("Visa Ungdomar eller pensionär");
                        int Age = AskForInt("Enter Age: ");
                        UngdomEllerPensionar(Age);
                        break;

                    case 2:
                        Console.WriteLine("Ange en godlycklig text och programmet visar testen tio gånger");
                        statement = Console.ReadLine();
                        PrintInLoop(statement);

                        break;
                    case 3:
                        // Console.WriteLine("Var god ange en mening");
                        // sentence = Console.ReadLine();
                        FindAWord();
                        break;

                    default:
                        Console.WriteLine("Du har tryckt på fel tangent och Det är ett felaktig input");
                        break;
                }
                Console.Write("Tryck på 'any key' för att fortsätta");
                Console.ReadKey();

            }

        }


        static void UngdomEllerPensionar(int findAge)
        {

            if (findAge < 20)
            {
                Console.WriteLine("Ungdompris 80kr");
            }
            else if (findAge > 64)
            {
                Console.WriteLine("Pensionärpris 90kr");
            }
            else
                Console.WriteLine("Standardpris: 120kr");
        }

        static void PrintInLoop(string statement1)
        {

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(statement1);
            }

        }




        static void FindAWord()
        {
            string[] findWord;
            string sentence;
            bool wordFail = true;


            while (wordFail)
            {
                Console.WriteLine("Var god ange en mening");
                sentence = Console.ReadLine();
                findWord = sentence.Split(' ');
                int count = findWord.Length;

                if (count > 2)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.White;
                    string thirdWord = findWord[2];
                    Console.WriteLine("Det tredje ord är (" + thirdWord + ")!");
                    wordFail = false;
                }
                else
                {
                    Console.Clear();
                    Console.Beep();
                    Console.ForegroundColor = ConsoleColor.Red;                     // if sentence if less then two words give warning in red
                    Console.WriteLine("Du har anget fel mening Var god ange tre ord mening\n\n");
                    wordFail = true;
                }
            }


        }
        private static int AskForInt(string question)
        {
            int value;
            bool parsed;
            string error = "";
            do
            {
                string input = AskForString(error + question);
                parsed = int.TryParse(input, out value);
                 error = "Jag kunde inte tolka värdet, det får bara innehålla siffror\n";
            } while (!parsed);

            return value;
        }

        private static string AskForString(string question)
        {
            Console.Write(question);
            return Console.ReadLine();
        }
    }
}
