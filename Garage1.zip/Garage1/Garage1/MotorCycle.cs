﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class MotorCycle : Vehicle
    {
        private double cylinderVolume;

        public double CylinderVolume
        {
            get { return cylinderVolume; }
            set { cylinderVolume = value; }
        }
    }
}
