﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class Program
    {
        static void Main(string[] args)
        {
            int arraySize = 10;
            bool quit = true;
            Vehicle[] vehicle = new Vehicle[arraySize];
            Car car = new Car();
            Boat boat = new Boat();
            Bus bus = new Bus();
            MotorCycle motorcycle = new MotorCycle();
            AirPlane airplane = new AirPlane();

            Console.WriteLine("Press anykey to create garage");
            Console.ReadKey();
            Garage<Vehicle> garage = new Garage<Vehicle>(11);
            
            do
            {
                Console.Clear();
                Console.WriteLine("Garage has been created!!!\n");
                Console.WriteLine("\nWelcome to the Garage \n>>>>>>>>>>>");
                Console.WriteLine("Press 1 to enter a vehicle to garage");
                Console.WriteLine("Press 2 to exit a vehicle from garage");
                Console.WriteLine("Press 3 to view vehicles to garage");
                Console.WriteLine("Press 4 to store existing vehicles");
                Console.WriteLine("Press 5 to load last stored vehicles");
                Console.WriteLine("Press 0 to exit the program");
                char input = ' ';
                try
                {
                    input = Console.ReadLine()[0];
                }
                catch
                {
                    Console.WriteLine("Please enter a valid number");
                }
            
            bool entries = true;
                switch (input)
                {
                    case '0':
                        return;
                    case '1':
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("Please make entries of the following!");
                            Console.WriteLine("Press 1 to enter a Car to garage");
                            Console.WriteLine("Press 2 to enter an AirPlane to garage");
                            Console.WriteLine("Press 3 to enter a Bus to garage");
                            Console.WriteLine("Press 4 to enter a Motorcycle to garage");
                            Console.WriteLine("Press 5 to enter a Boat to garage");
                            Console.WriteLine("Press 0 if you don't want to make vehicle entries");
                            char forGarageEntries = ' ';
                            try
                            {
                                forGarageEntries = Console.ReadLine()[0];
                            }
                            catch
                            {
                                Console.WriteLine("Please enter a valid number");
                            }
                            switch (forGarageEntries)
                            {
                                case '1':
                                    addCar(car);
                                    car.Fuel = Car.FuelType.Diesel;
                                    break;
                                case '2':
                                    garage.Add(airplane);
                                    break;
                                case '3':
                                    garage.Add(bus);
                                    break;
                                case '4':
                                    garage.Add(motorcycle);
                                    break;
                                case '5':
                                    garage.Add(boat);
                                    break;
                                case '0':
                                    entries = false;
                                    break;
                            }
                            
                        } while (entries);
                        
                        

                        
                        break;
                    case '2':
                        
                        break;
                    case '3':
                        break;
                    case '4':
                        break;
                    case '5':
                        break;
                    case '6':
                        break;


                }

                entries = true;

            } while (quit);


            Console.Read();
        }

        private static void addCar(Car car)
        {
            
        }
    }
}
