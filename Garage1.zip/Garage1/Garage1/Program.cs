﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class Program
    {
        static Garage<Vehicle> garage;
        static int arraySize = 10;
        static void Main(string[] args)
        {
            Vehicle[] vehicle;
            vehicle = new Vehicle[10];
            bool quit = true;
            Console.WriteLine("Press anykey to create garage");
            Console.ReadKey();
            //arraySize = Convert.ToInt32(Console.ReadLine());
            garage = new Garage<Vehicle>(arraySize);

            do
            {
                Console.Clear();
                Console.WriteLine("Garage has been created!!!\n");
                Console.WriteLine("\nWelcome to the Garage \n>>>>>>>>>>>");
                Console.WriteLine("Press 1 to enter a vehicle to garage");
                Console.WriteLine("Press 2 to exit a vehicle from garage");
                Console.WriteLine("Press 3 to view vehicles to garage");
                Console.WriteLine("Press 4 to store existing vehicles");
                Console.WriteLine("Press 5 to load last stored vehicles");
                Console.WriteLine("Press 0 to exit the program");
                char input = ' ';
                try
                {
                    input = Console.ReadLine()[0];
                }
                catch
                {
                    Console.WriteLine("Please enter a valid number");
                }

                bool entries = true;
                switch (input)
                {
                    case '0':
                        return;
                    case '1':
                        #region Entries of Vehicles
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("Please make entries of the following!");
                            Console.WriteLine("Press 1 to enter a Car to garage");
                            Console.WriteLine("Press 2 to enter an AirPlane to garage");
                            Console.WriteLine("Press 3 to enter a Bus to garage");
                            Console.WriteLine("Press 4 to enter a Motorcycle to garage");
                            Console.WriteLine("Press 5 to enter a Boat to garage");
                            Console.WriteLine("Press 0 if you don't want to make vehicle entries");
                            char forGarageEntries = ' ';
                            try
                            {
                                forGarageEntries = Console.ReadLine()[0];
                            }
                            catch
                            {
                                Console.WriteLine("Please enter a valid number");
                            }
                            switch (forGarageEntries)
                            {
                                case '1':
                                    addCar();
                                    break;
                                case '2':
                                    addAirplane();
                                    break;
                                case '3':
                                    addBus();
                                    break;
                                case '4':
                                    addMotorcycle();
                                    break;
                                case '5':
                                    addBoat();
                                    break;
                                case '0':
                                    entries = false;
                                    break;
                            }

                        } while (entries);
                        #endregion

                        break;
                    case '2':
                        removeVehicle();

                        break;
                    case '3':
                        showVehicles();
                        break;
                    case '4':
                        break;
                    case '5':
                        break;
                    case '6':
                        break;


                }

                entries = true;

            } while (quit);


            Console.Read();
        }

        private static void removeVehicle()
        {

        }

        private static void showVehicles()
        {
            foreach (var item in garage)
            {
                Console.WriteLine(item);
            }
            Console.Read();
        }

        private static void addBoat()
        {

            Vehicle boat = new Boat() { Length = 500.55f, Name = "IronMan", Color = "White", RegNumber = "ABC123" };
            Vehicle boat1 = new Boat() { Length = 550.55f, Name = "IrishLady", Color = "Pink", RegNumber = "IJK123" };
            
            //boat.Name = Console.ReadLine();
            if (garage.Count == arraySize)
            {
                Console.WriteLine("You can not park more vehicles please wait.");
            }
            else
            {
                garage.Add(boat);
                foreach (var item in garage)
                {
                    Console.WriteLine($"Entries:{item} and vehicles are now: {garage.Count}");
                }
            }
            Console.Read();

        }

        private static void addMotorcycle()
        {
            Vehicle motorcycle = new MotorCycle();
            if (garage.Count == arraySize)
            {
                Console.WriteLine("You can not park more vehicles please wait.");
            }
            else
            {
                garage.Add(motorcycle);
                foreach (var item in garage)
                {
                    Console.WriteLine($"Entries:{item} and vehicles are now: {garage.Count}");
                }
            }
            Console.Read();
        }

        private static void addBus()
        {
            Vehicle bus = new Bus();
            if (garage.Count == arraySize)
            {
                Console.WriteLine("You can not park more vehicles please wait.");
            }
            else
            {
                garage.Add(bus);
                foreach (var item in garage)
                {
                    Console.WriteLine($"Entries:{item} and vehicles are now: {garage.Count}");
                }
            }
            Console.Read();
        }

        private static void addAirplane()
        {
            Vehicle airplane = new AirPlane();
            if (garage.Count == arraySize)
            {
                Console.WriteLine("You can not park more vehicles please wait.");
            }
            else
            {
                garage.Add(airplane);
                foreach (var item in garage)
                {
                    Console.WriteLine($"Entries:{item} and vehicles are now: {garage.Count}");
                }
            }
            Console.Read();
        }

        private static void addCar()
        {
            Car car = new Car() { NumberOfWheels = 4, RegNumber = "RYI300" };
            car.Fuel = Car.FuelType.Diesel;
            if (garage.Count == arraySize)
            {
                Console.WriteLine("You can not park more vehicles please wait.");
            }
            else {
                garage.Add(car);
                Console.WriteLine($"Reg Number{car.RegNumber}");
                foreach (var item in garage)
                {
                    //Console.WriteLine($"Color: {car.Name} Fuel type:{car.Fuel} { car.Name} {car.RegNumber}");
                    Console.WriteLine($"Entries:{item} and vehicles are now: {garage.Count}");
                }
            }
            Console.Read();
        }
    }
}
