﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class Program
    {
        static Garage<Vehicle> garage;
        //static Vehicle[] vehicle;
        static int garageSize = 10;
        static void Main(string[] args)
        {
            //vehicle = new Vehicle[10];
            bool quit = true;
            Console.WriteLine("Press anykey to create garage");
            Console.ReadKey();
            garage = new Garage<Vehicle>(garageSize);

            do
            {
                Console.WriteLine("Garage has been created!!!\n");
                Console.Clear();
                Console.WriteLine("\nWelcome to the Garage \n>>>>>>>>>>>");
                Console.WriteLine("Press 1 to enter a vehicle to garage");
                Console.WriteLine("Press 2 to exit a vehicle from garage");
                Console.WriteLine("Press 3 to view vehicles to garage");
                //Console.WriteLine("Press 4 to store existing vehicles");
                //Console.WriteLine("Press 5 to load last stored vehicles");
                Console.WriteLine("Press 0 to exit the program");


                //char input = ' ';
                //try
                //{
                //    input = Console.ReadLine()[0];
                //}
                //catch
                //{
                //    Console.WriteLine("Please enter a valid number");
                //}

                var key = Console.ReadKey(intercept: true).Key;
                bool parkMore = true;
                switch (key)
                {
                    case ConsoleKey.D0:
                        return;
                    case ConsoleKey.D1:
                        #region Entries of Vehicles
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("Please make entries of the following!");
                            Console.WriteLine("Press 1 to enter a Car to garage");
                            Console.WriteLine("Press 2 to enter an AirPlane to garage");
                            Console.WriteLine("Press 3 to enter a Bus to garage");
                            Console.WriteLine("Press 4 to enter a Motorcycle to garage");
                            Console.WriteLine("Press 5 to enter a Boat to garage");
                            Console.WriteLine("Press 0 if you don't want to make vehicle entries");
                            char forGarageEntries = ' ';
                            try
                            {
                                forGarageEntries = Console.ReadLine()[0];
                            }
                            catch
                            {
                                Console.WriteLine("Please enter a valid number");
                            }
                            switch (forGarageEntries)
                            {
                                case '1':
                                    addCar();
                                    break;
                                case '2':
                                    addAirplane();
                                    break;
                                case '3':
                                    addBus();
                                    break;
                                case '4':
                                    addMotorcycle();
                                    break;
                                case '5':
                                    addBoat();
                                    break;
                                case '0':
                                    parkMore = false;
                                    break;
                            }

                        } while (parkMore);
                        #endregion

                        break;
                    case ConsoleKey.D2:
                        removeVehicle();
                        break;
                    case ConsoleKey.D3:
                        showVehicles();
                        break;
                    case ConsoleKey.D4:
                        break;
                    case ConsoleKey.D5:
                        break;
                    case ConsoleKey.D6:
                        break;
                    default:
                        Console.WriteLine("Please enter a valid number");
                        break;
                }
                parkMore = true;
            } while (quit);
            Console.Read();
        }

        private static void removeVehicle()
        {

            foreach (var item in garage)
            {
                Console.WriteLine($"{item}\t\t Reg nr:{item.RegNumber}");
            }
            Console.WriteLine("Please enter reg nr to remove vehicle");
            string regNr = Console.ReadLine();
            var vehicleToRemove = garage
                .Where(storeTemp => storeTemp.RegNumber.ToUpper() == regNr.ToUpper())
                .FirstOrDefault();
            if (vehicleToRemove != null)
            {
                garage.Remove(vehicleToRemove);
                Console.WriteLine($"The vehicle has left the garage: {vehicleToRemove.RegNumber}");
            }
            else
            {
                Console.WriteLine($"I can't find a vehicle with reg no {regNr}.");
            }

            Console.Read();
        }

        private static void showVehicles()
        {

            foreach (var item in garage)
            {
                Console.WriteLine(item.Stats());
                Console.WriteLine();
                Console.ReadKey(intercept: true);
                //Console.WriteLine($"\n\n{item.GetType().Name} \t  Name: {item.Name}\t\t RegNr:" +
                // $"{item.RegNumber}\t\t  Color: {item.Color}\t\tNr of Wheels:{item.NumberOfWheels}\t ");

                //UniqueProperties(item);
            }
            //int numberOfWheels = AskForInt("Find by wheels: ");
            //foreach (var item in garage)
            //{
            //    if (item.NumberOfWheels == numberOfWheels)
            //    {
            //        Console.WriteLine($"{item} Name:{item.GetType().Name}");
            //    }
            //}

            Console.Read();
        }
        #region add vehicles
        private static void addBoat()
        {
            Console.Clear();
            // bool check = true;
            var boat = new Boat();
            CommonData(boat);
            boat.Length = AskForDouble("Boat length: ");

            parked(boat);

        }

        private static void addMotorcycle()
        {
            Console.Clear();
            var motorcycle = new MotorCycle();
            CommonData(motorcycle);
            motorcycle.CylinderVolume = AskForInt("Cylinder volume: ");

            parked(motorcycle);
        }



        private static void addBus()
        {
            Console.Clear();
            var bus = new Bus();
            CommonData(bus);
            bus.NumberOfSeats = AskForInt("Number of seats: ");

            parked(bus);
        }

        private static void addAirplane()
        {
            Console.Clear();
            var airplane = new AirPlane();
            CommonData(airplane);
            airplane.NumberOfEngines = AskForInt("Number of engines: ");

            parked(airplane);
        }

        private static void addCar()
        {
            Console.Clear();
            var car = new Car();
            CommonData(car);
            #region For car enum
            var enumvalues = Enum.GetValues(typeof(FuelType));
            int count = 0;
            foreach (var item in enumvalues)
            {
                Console.WriteLine($"enter {count} for  {item}");
                count += 1;
            }
            bool fuelEntry = true;
            do
            {
                int fuelTypeInteger;
                fuelTypeInteger = AskForInt("Enter a digit: ");
                if (Enum.IsDefined(typeof(FuelType), fuelTypeInteger))
                {
                    car.Fuel = (FuelType)fuelTypeInteger;
                }
                else {
                    Console.WriteLine("Please enter between 0 to " + (enumvalues.Length - 1));
                }

                //switch (fuelTypeInteger)
                //{
                //    case 0:
                //        car.Fuel = (FuelType)fuelTypeInteger;
                //        fuelEntry = false;
                //        break;
                //    case 1:
                //        car.Fuel = FuelType.Diesel;
                //        fuelEntry = false;
                //        break;
                //    case 2:
                //        car.Fuel = FuelType.Hybrid;
                //        fuelEntry = false;
                //        break;
                //    case 3:
                //        car.Fuel = FuelType.Ethanol;
                //        fuelEntry = false;
                //        break;
                //    default:
                fuelEntry = true;
                break;
            
            } while (fuelEntry);
            #endregion
            parked(car);
    }
    #endregion
    #region Common vehicle properties
    private static Vehicle CommonData(Vehicle vehicle)
    {
        //bool refNumber = true;

        vehicle.Name = CorrectEntries("Enter Name:");
        vehicle.RegNumber = CorrectEntries("Enter Registration number:");
        vehicle.Color = CorrectEntries("Enter Color:");
        vehicle.NumberOfWheels = AskForInt("Number of wheels:");
        return vehicle;
    }
    #endregion
    #region Show vehicles
    private static void parked(Vehicle vehicle)
    {
        if (garage.Count == garageSize)
        {
            Console.WriteLine("You can not park more vehicles please wait.");
        }
        else
        {
            garage.Add(vehicle);
            Console.WriteLine($"The garage now has {garage.Count} vehicles");
            //foreach (var item in garage)
            //{
            //    Console.WriteLine($"  {item.Name}");
            //}
        }
        Console.Read();
    }
    #endregion
    #region Data entry
    private static string CorrectEntries(string v)
    {
        string input;
        do
        {
            input = AskForString(v);
        } while (input == null || input == "");
        return input;
    }
    private static int AskForInt(string question)
    {

        int value;
        bool parsed;
        string error = "";
        do
        {
            string input = AskForString(question + error);
            parsed = int.TryParse(input, out value);
            error = "Enter only integer values";
        } while (!parsed); //(parsed == false)

        return value;
    }
    private static double AskForDouble(string question)
    {

        double value;
        bool parsed;
        string error = "";
        do
        {
            string input = AskForString(question + error);
            parsed = double.TryParse(input, out value);
            error = "Use only decimals";
        } while (!parsed); //(parsed == false)

        return value;
    }

    private static string AskForString(string question)
    {
        Console.Write(question);
        return Console.ReadLine();

    }
    #endregion
    #region Unique properties
    //private static void UniqueProperties(Vehicle item)
    //{
     
    //    switch (item.GetType().Name)
    //    {
    //        case "Airplane":
    //            Console.WriteLine($"\nUnique type::Nr of enogines: {(item as AirPlane).NumberOfEngines}");
    //            break;
    //        case "Bus":
    //            Console.WriteLine($"\nUnique type::Nr of seats:{(item as Bus).NumberOfSeats}");
    //            break;
    //        case "Motorcycle":
    //            Console.WriteLine($"\nUnique type::Volume of cylinder{(item as MotorCycle).CylinderVolume}");
    //            break;
    //        case "Car":
    //            Console.WriteLine($"\nUnique type::Fuel type: {(item as Car).Fuel}");
    //            break;
    //        case "Boat":
    //            Console.WriteLine($"\nUnique type::Boat length {(item as Boat).Length}");
    //            break;
    //        default:
    //            break;
    //    }
    //}
    #endregion
}
}
