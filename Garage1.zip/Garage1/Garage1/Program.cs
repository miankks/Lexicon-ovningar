﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class Program
    {
        static Garage<Vehicle> garage;
        static Vehicle[] vehicle;
        static int arraySize = 10;
        static void Main(string[] args)
        {
            vehicle = new Vehicle[10];
            bool quit = true;
            Console.WriteLine("Press anykey to create garage");
            Console.ReadKey();
            garage = new Garage<Vehicle>(arraySize);

            do
            {
                Console.Clear();
                Console.WriteLine("Garage has been created!!!\n");
                Console.WriteLine("\nWelcome to the Garage \n>>>>>>>>>>>");
                Console.WriteLine("Press 1 to enter a vehicle to garage");
                Console.WriteLine("Press 2 to exit a vehicle from garage");
                Console.WriteLine("Press 3 to view vehicles to garage");
                Console.WriteLine("Press 4 to store existing vehicles");
                Console.WriteLine("Press 5 to load last stored vehicles");
                Console.WriteLine("Press 0 to exit the program");
                char input = ' ';
                try
                {
                    input = Console.ReadLine()[0];
                }
                catch
                {
                    Console.WriteLine("Please enter a valid number");
                }

                bool entries = true;
                switch (input)
                {
                    case '0':
                        return;
                    case '1':
                        #region Entries of Vehicles
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("Please make entries of the following!");
                            Console.WriteLine("Press 1 to enter a Car to garage");
                            Console.WriteLine("Press 2 to enter an AirPlane to garage");
                            Console.WriteLine("Press 3 to enter a Bus to garage");
                            Console.WriteLine("Press 4 to enter a Motorcycle to garage");
                            Console.WriteLine("Press 5 to enter a Boat to garage");
                            Console.WriteLine("Press 0 if you don't want to make vehicle entries");
                            char forGarageEntries = ' ';
                            try
                            {
                                forGarageEntries = Console.ReadLine()[0];
                            }
                            catch
                            {
                                Console.WriteLine("Please enter a valid number");
                            }
                            switch (forGarageEntries)
                            {
                                case '1':
                                    addCar();
                                    break;
                                case '2':
                                    addAirplane();
                                    break;
                                case '3':
                                    addBus();
                                    break;
                                case '4':
                                    addMotorcycle();
                                    break;
                                case '5':
                                    addBoat();
                                    break;
                                case '0':
                                    entries = false;
                                    break;
                            }

                        } while (entries);
                        #endregion

                        break;
                    case '2':
                        removeVehicle();
                        break;
                    case '3':
                        showVehicles();
                        break;
                    case '4':
                        break;
                    case '5':
                        break;
                    case '6':
                        break;
                }
                entries = true;
            } while (quit);


            Console.Read();
        }

        private static void removeVehicle()
        {
            var vehToRemove = new Vehicle();

            foreach (var item in garage)
            {
                Console.WriteLine(item.RegNumber);
            }
            Console.WriteLine("Please enter reg nr to remove vehicle");
            string regNr = Console.ReadLine();
            vehToRemove = garage.Where(storeTemp => storeTemp.RegNumber == regNr).FirstOrDefault();
            if (vehToRemove != null)
            {
                garage.Remove(vehToRemove);
                Console.WriteLine($"The vehicle has left the garage: {vehToRemove.RegNumber}");
            }
            else
            {
                Console.WriteLine("Location is empty");
            }

            Console.Read();
        }

        private static void showVehicles()
        {

            foreach (var item in garage)
            {

                Console.WriteLine($"Name: {item.Name}\t\t RegNr: {item.RegNumber}\t\t  Color: {item.Color}");
            }
            Console.Read();
        }

        private static void addBoat()
        {

            var boat = new Boat();
            Console.WriteLine("Enter boat name");
            boat.Name = Console.ReadLine();
            Console.WriteLine("Enter boat Registration number");
            boat.RegNumber = Console.ReadLine();
            Console.WriteLine("Enter boat color");
            boat.Color = Console.ReadLine();
            Console.WriteLine("Enter boat number of wheel");
            boat.NumberOfWheels = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter boat length");
            boat.Length = Convert.ToDouble(Console.ReadLine());

            parked(boat);

        }

        private static void addMotorcycle()
        {

            var motorcycle = new MotorCycle();
            Console.WriteLine("Enter airplane name");
            motorcycle.Name = Console.ReadLine();
            Console.WriteLine("Enter airplane Registration number");
            motorcycle.RegNumber = Console.ReadLine();
            Console.WriteLine("Enter airplane color");
            motorcycle.Color = Console.ReadLine();
            Console.WriteLine("Enter airplane number of engines");
            motorcycle.NumberOfWheels = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter cylinder volume");
            motorcycle.CylinderVolume = Convert.ToDouble(Console.ReadLine());

            parked(motorcycle);
        }



        private static void addBus()
        {
            var bus = new Bus();
            Console.WriteLine("Enter bus name");
            bus.Name = Console.ReadLine();
            Console.WriteLine("Enter bus registration number");
            bus.RegNumber = Console.ReadLine();
            Console.WriteLine("Bus color");
            bus.Color = Console.ReadLine();
            Console.WriteLine("Number of wheels");
            bus.NumberOfWheels = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Number of seats");
            bus.NumberOfSeats = Convert.ToInt16(Console.ReadLine());

            parked(bus);
        }

        private static void addAirplane()
        {
            var airplane = new AirPlane();
            Console.WriteLine("Enter airplane name");
            airplane.Name = Console.ReadLine();
            Console.WriteLine("Enter airplane Registration number");
            airplane.RegNumber = Console.ReadLine();
            Console.WriteLine("Enter airplane color");
            airplane.Color = Console.ReadLine();
            Console.WriteLine("Enter airplane number of wheels");
            airplane.NumberOfWheels = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter airplane number of engines");
            airplane.NumberOfEngines = Convert.ToInt16(Console.ReadLine());

            parked(airplane);
        }

        private static void addCar()
        {
            var car = new Car();
            Console.WriteLine("Enter airplane name");
            car.Name = Console.ReadLine();
            Console.WriteLine("Enter airplane Registration number");
            car.RegNumber = Console.ReadLine();
            Console.WriteLine("Enter airplane color");
            car.Color = Console.ReadLine();
            car.Fuel = Car.FuelType.Hybrid;
            Console.WriteLine("Enter car number of wheels");
            car.NumberOfWheels = Convert.ToInt16(Console.ReadLine());
            parked(car);
        }
        private static void parked(Vehicle vehicle)
        {
            if (garage.Count == arraySize)
            {
                Console.WriteLine("You can not park more vehicles please wait.");
            }
            else
            {
                garage.Add(vehicle);
                foreach (var item in garage)
                {
                    Console.WriteLine($"Entries:{item} and vehicles are now: {garage.Count}");
                }
            }
            Console.Read();
        }
    }
}
