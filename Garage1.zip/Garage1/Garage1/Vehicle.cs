﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    /// <summary>
    /// For different type vehicles
    /// </summary>
    class Vehicle
    {
        #region Fields and properties
        private string regNumber;

        public string RegNumber
        {
            get { return regNumber; }
            set { regNumber = value; }
        }
        private string color;

        public string Color
        {
            get { return color; }
            set { color = value; }
        }
        private int noOfWheels;

        public int NoOfWheels
        {
            get { return noOfWheels; }
            set { noOfWheels = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        #endregion
    }
}
