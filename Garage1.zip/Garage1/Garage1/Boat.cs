﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class Boat : Vehicle
    {
        private float length;

        public float Length
        {
            get { return length; }
            set { length = value; }
        }
    }
}
