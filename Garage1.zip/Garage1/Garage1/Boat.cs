﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class Boat : Vehicle
    {
        public float Length { get; set; }
    }
}
