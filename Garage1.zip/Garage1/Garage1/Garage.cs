﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    /// <summary>
    /// For parking vehicles
    /// </summary>
    class Garage<TVehicles> : IEnumerable<TVehicles> where TVehicles : Vehicle
    {
        private TVehicles[] vehicle;

        public int Capacity { get; }
        public int Count { get; private set; }

        public Garage(int capacity)
        {
            Capacity = capacity;
            vehicle = new TVehicles[capacity];
        }

        public bool Add(TVehicles vehicle)
        {
            if (Count >= Capacity) return false;

            for (int i = 0; i < Capacity; i++)
            {
                if (this.vehicle[i] == null)
                {
                    this.vehicle[i] = vehicle;
                    Count += 1;
                    return true;
                }
            }
            return false;
        }

        public TVehicles Remove(TVehicles vehicle)
        {
            for (int i = 0; i < Capacity; i++)
            {
                if (this.vehicle[i].RegNumber==vehicle.RegNumber)
                {
                    this.vehicle[i] = null;
                    Count -= 1; 
                    return vehicle;
                }
            }
            return default(TVehicles);
        }

        public IEnumerator<TVehicles> GetEnumerator()
        {
            for (int i = 0; i < Capacity; i++)
            {
                if (vehicle[i] != null)
                {
                    yield return vehicle[i];
                }
            }
        }

       IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}

