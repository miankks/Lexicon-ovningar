﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
       public enum FuelType { Gasoline=0, Diesel=1, Hybrid=2, Ethanol=3}
    class Car : Vehicle
    {
        public FuelType Fuel { get; set; }
        public override string Stats()
        {
            return base.Stats() + $"\nFuel Type: {Fuel}";
        }

        //public Car()
        //{
        //    var values = Enum.GetValues(Fuel.GetType());
        //}
        //public void SetFuelType()
        //{
        //    Console.WriteLine("Fuel type: ");
        //    int fuelType =Convert.ToInt16( Console.ReadLine());
        //    switch (fuelType)
        //    {
        //        case 1:

        //            break;
        //    }
        //}


    }
}
