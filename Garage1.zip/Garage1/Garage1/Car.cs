﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage1
{
    class Car : Vehicle
    {
       public enum FuelType { Gasoline, Diesel, Hybrid, Ethanol}
        public FuelType Fuel { get; set; }
       

    }
}
