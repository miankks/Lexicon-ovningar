﻿namespace Donjon
{
    internal class Hero
    {
        public int Health;
        public int X { get; set; }
        public int Y { get; set; }

        public int Damage { get; set; } = 10;
        
        public Hero(int health)
        {
            Health = health;
        }
    }
}