﻿namespace Donjon
{
    internal class Cell
    {
        public Monster Monster { get; set; }
    }
}